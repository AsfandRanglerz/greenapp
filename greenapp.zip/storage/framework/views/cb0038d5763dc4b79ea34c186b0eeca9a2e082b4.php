<div id="dashboardSidebar">
    <div class="mb-4 user-name-block">
        <a href="#" class="my-4 d-block text-center"><img src="<?php echo e(asset('public/user/images/logo.png')); ?>"
                alt="logo" class="logo-img" /></a>
        <h5 class="mt-3 text-white text-center"><?php echo e(Auth::guard('company')->user()->name); ?></h5>
    </div>
    <aside class="side-nav opend active">
        <ul class="mb-0 side-nav-links">
            <li class="position-relative">
                <a href="<?php echo e(route('company.dashboard')); ?>" class="sidebar-links"><span
                        class="fa fa-home text-white pr-2 sidebar-link-icons"></span>Dashboard</a>
            </li>
            <li class="position-relative">
                <a href="<?php echo e(route('company.profile.index')); ?>" class="sidebar-links"><span
                        class="fa fa-building text-white pr-2 sidebar-link-icons"></span>Profile</a>
            </li>
            <li class="position-relative <?php echo e(request()->is('employee*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('company.employee.index')); ?>" class="sidebar-links"><span
                        class="fa fa-users text-white pr-2 sidebar-link-icons"></span>Employees</a>
            </li>
            <li class="position-relative <?php echo e(request()->is('document*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('company.document.index')); ?>" class="sidebar-links"><span
                        class="fa fa-book text-white pr-2 sidebar-link-icons"></span>Documents/Attachments</a>
            </li>
            <li class="position-relative ">
                <a href="<?php echo e(route('company.ChangePassword.index')); ?>" class="sidebar-links"><span
                        class="fa fa-lock text-white pr-2 sidebar-link-icons"></span>Change Password</a>
            </li>

            <li class="position-relative <?php echo e(request()->is('faqs*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('company.faqs')); ?>" class="sidebar-links"><span
                        class="fa fa-question-circle text-white pr-2 sidebar-link-icons"></span>FAQ's</a>
            </li>
            <li class="position-<?php echo e(request()->is('about-us*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('company.about-us')); ?>" class="sidebar-links"><span
                        class="fa fa-info-circle text-white pr-2 sidebar-link-icons"></span>About Us</a>
            </li>
            <li class="position-relative <?php echo e(request()->is('privacy-policy*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('company.privacy-policy')); ?>" class="sidebar-links"><span
                        class="fa fa-lock text-white pr-2 sidebar-link-icons"></span>Privacy Policy</a>
            </li>
            <li class="position-relative <?php echo e(request()->is('term-condition*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('company.term-condition')); ?>" class="sidebar-links"><span
                        class="fa fa-key text-white pr-2 sidebar-link-icons"></span>Terms & Conditions</a>
            </li>
            <li class="position-relative">
                <a href="<?php echo e(route('company.logout')); ?>" class="sidebar-links"><span
                        class="fa fa-sign-out-alt text-white pr-2 sidebar-link-icons"></span>Logout</a>
            </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\Ranglerz\greenapp\resources\views/company/common/sidebar.blade.php ENDPATH**/ ?>