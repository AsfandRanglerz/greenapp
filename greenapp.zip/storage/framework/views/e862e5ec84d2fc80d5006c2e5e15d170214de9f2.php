
<?php $__env->startSection('content'); ?>
    <div class="admin-main-content-inner">
        <div class="dashboard-front-pg">
            <h4>Company Dashboard</h4>
            <p><span class="fa fa-home"></span> - Main Overview</p>
            <div class="row mb-sm-3">
                <div class="col-sm-4 mb-sm-3 mb-1 wow fadeInUp" data-wow-duration="2s">
                    <p class="font-weight-bold small mb-0 text-center">Trade License No #
                        <?php echo e($company->license_no ?? ''); ?>

                    </p>
                </div>
                <div class="col-sm-4 mb-sm-3 mb-1 wow fadeInUp" data-wow-duration="2s">
                    <p class="font-weight-bold small mb-0 text-center">Establishment Card No #
                        <?php echo e($company->establishment_no ?? ''); ?></p>
                </div>
                <div class="col-sm-4 mb-sm-3 mb-1 wow fadeInUp" data-wow-duration="2s">
                    <p class="font-weight-bold small mb-0 text-center">MOHRE Company Code #
                        <?php echo e($company->mohre_no ?? ''); ?>

                    </p>
                </div>
                <div class="col-sm-4 col-8 mx-auto mt-sm-0 my-3 wow fadeInUp" data-wow-duration="2s">
                    <a href="<?php echo e(route('company.employee.index')); ?>"
                        class="p-3 text-decoration-none rounded light-box-shadow d-flex flex-column justify-content-center align-items-center total-block-section">
                        <h5 class="text-center mb-4 theme-color">Total Employees</h5>
                        <span class="block-badge"><?php echo e($employee); ?></span>
                    </a>
                </div>
                <div class="col-sm-4 col-8 mx-auto mb-3 wow fadeInUp" data-wow-duration="2s">
                    <a href="<?php echo e(route('company.document.index')); ?>"
                        class="p-3 text-decoration-none rounded light-box-shadow d-flex flex-column justify-content-center align-items-center total-block-section">
                        <h5 class="text-center mb-4 theme-color">Company Documents</h5>
                        <span class="block-badge"><?php echo e($companyDocument); ?></span>
                    </a>
                </div>
                <div class="col-sm-4 col-8 mx-auto mb-3 wow fadeInUp" data-wow-duration="2s">
                    <a href="<?php echo e(route('company.document.index')); ?>"
                        class="p-3 text-decoration-none rounded light-box-shadow d-flex flex-column justify-content-center align-items-center total-block-section">
                        <h5 class="text-center mb-4 theme-color">Employee Documents</h5>
                        <span class="block-badge"><?php echo e($employeeDocument); ?></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('company.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ranglerz\greenapp\resources\views/company/dashboard.blade.php ENDPATH**/ ?>