
<?php $__env->startSection('content'); ?>
    <div class="col-xl-4 col-lg-6 col-sm-8 col-11 px-0 mx-auto auth-form light-box-shadow">
        <div class="auth-form-block-header">
            <div class="position-relative auth-form-block-header-inner">
                <a class="navbar-brand" href="./" style="position: absolute;right: 0"><img
                        src="<?php echo e(asset('public/user/images/logo.png')); ?>" alt="logo" class="logo-img"></a>
                <button onclick="history.back()" class="py-0 px-2 btn btn-success mb-2 back-btn"><span class="fa fa-angle-left mr-2"></span>Back</button>
                <p class="mb-2 text-white">Welcome</p>
                <p class="mb-0 text-white">Please login to your account</p>
                <h5 class="text-white mb-0">Green App</h5>
            </div>
            <div class="PolygonRuler"><svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none"
                    xmlns="http://www.w3.org/2000/svg" class="PolygonRuler__SVG">
                    <polygon points="2560 0 2560 100 0 100" class="PolygonRuler__Polygon PolygonRuler__Polygon--fill-white">
                    </polygon>
                </svg></div>
        </div>
        <form id="authForm" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h3 class="text-center mb-4">Login</h3>
            <div class="form-group">
                <label for="userEmail">Email/Phone<span class="required"> *</span></label>
                <div class="position-relative d-flex align-items-center">
                    <span class="position-absolute fa fa-envelope input-field-left-icon"></span>
                    <input id="userEmail" name="email" type="text" value="<?php echo e(old('email')); ?>"class="form-control pl-pr-padding"
                        placeholder="Enter Your Email or Mobile Number">
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger p-2"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="userPassword">Password<span class="required"> *</span></label>
                <div class="position-relative d-flex align-items-center">
                    <span class="position-absolute fa fa-lock input-field-left-icon"></span>
                    <input id="userPassword" name="password" type="password" class="form-control pl-pr-padding"
                        placeholder="Password">
                    <span toggle="#userPassword" class="fa fa-fw fa-eye preview-eye-icon toggle-password"
                        aria-hidden="true"></span>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger p-2"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-2 text-right">
                    <a href="<?php echo e(url('forget-password')); ?>" class="text-dark font-weight-600">Forgot Password?</a>
                </div>
            </div>
            <div class="mt-xl-5 mb-xl-2 my-sm-3 mt-3">
                <button type="submit" class="w-100 btn-bg">Login</button>
                <p class="text-center text-dark font-weight-600 mt-2 mb-0">Don't have an account? <a
                        href="<?php echo e(url('register')); ?>" class="green-link">Register</a></p>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
        toastr.success('<?php echo e(\Illuminate\Support\Facades\Session::get('success')); ?>');
    <?php endif; ?>

    <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
        toastr.error('<?php echo e(\Illuminate\Support\Facades\Session::get('error')); ?>');
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ranglerz\greenapp\resources\views/auth/login.blade.php ENDPATH**/ ?>