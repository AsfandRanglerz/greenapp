<?php $__env->startComponent('mail::message'); ?>
<h1 style="margin:0 auto 10px;width:145px">Registration</h1>

<p>Dear <?php echo e($data['name']); ?>,</p>
<p>Thank you for registering your company with us. We have received the following information:</p>

<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>

<p>We will review your registration.</p>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\xampp\htdocs\Ranglerz\greenapp\resources\views/emails/company_register.blade.php ENDPATH**/ ?>