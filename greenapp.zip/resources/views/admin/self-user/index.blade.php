@extends('admin.layout.app')

@section('title', 'index')

@section('content')

    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="col-12">
                                    <h4>Self Registered Employees</h4>
                                </div>
                            </div>
                            <div class="card-body table-striped table-bordered table-responsive">
                                <a class="btn btn-success mb-3" href="{{ route('selfemployee.create') }}">Add Employee</a>
                                <table class="table text-center" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Name</th>
                                            <th>Image</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>DOB</th>
                                            <th>Gender</th>
                                            <th>Nationality</th>
                                            <th>Religion</th>
                                            <th>Father Name</th>
                                            <th>Mother Name</th>
                                            <th>Passport Number</th>
                                            <th>Unified Number</th>
                                            <th>Emirates ID Number</th>
                                            <th>Work Permit Number</th>
                                            <th>Person Code</th>
                                            <th>Document</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($users as $employee)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $employee->name }}</td>
                                                <td><a target="_black" href="{{ asset('') . '/' . $employee->image }}">
                                                        <img src="{{ asset('') . '/' . $employee->image }}" alt=""
                                                            height="50" width="50" class="image"></a>
                                                </td>
                                                <td>{{ $employee->email }}</td>
                                                <td>{{ $employee->phone }}</td>
                                                <td>{{ $employee->dob }}</td>
                                                <td>{{ $employee->gender }}</td>
                                                <td>{{ $employee->nationality }}</td>
                                                <td>{{ $employee->religion }}</td>
                                                <td>{{ $employee->father_name }}</td>
                                                <td>{{ $employee->mother_name }}</td>
                                                <td>{{ $employee->passport_number }}</td>
                                                <td>{{ $employee->unified_number }}</td>
                                                <td>{{ $employee->emirate_id_number }}</td>
                                                <td>{{ $employee->work_permit_number }}</td>
                                                <td>{{ $employee->person_code }}</td>
                                                <td>
                                                    <a href="{{ route('user-document.index', $employee->id) }}">View</a>
                                                </td>

                                                <td
                                                    style="display: flex;align-items: center;justify-content: center;column-gap: 8px">
                                                    <a class="btn btn-info"
                                                        href="{{ route('selfemployee.edit', $employee->id) }}">Edit</a>
                                                    <form method="post"
                                                        action="{{ route('selfemployee.destroy', $employee->id) }}">
                                                        @csrf
                                                        <input name="_method" type="hidden" value="DELETE">
                                                        <button type="submit" class="btn btn-danger btn-flat show_confirm"
                                                            data-toggle="tooltip">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

@endsection

@section('js')
    <script>
        @if (\Illuminate\Support\Facades\Session::has('success'))
            toastr.success('{{ \Illuminate\Support\Facades\Session::get('success') }}');
        @endif

        @if (\Illuminate\Support\Facades\Session::has('error'))
            toastr.error('{{ \Illuminate\Support\Facades\Session::get('error') }}');
        @endif
    </script>

    <script>
        $(document).ready(function() {
            $('#table_id_events').DataTable();
        });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>
@endsection
