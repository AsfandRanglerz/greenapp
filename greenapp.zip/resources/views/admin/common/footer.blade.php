<footer class="main-footer">
    <div class="footer-left">
        <p>Powered By <a href="https://www.ranglerz.com/" target="_blank" style="color: #FFF!important">RANGLERZ</a></p>
    </div>
    <div class="footer-right">
    </div>
</footer>
